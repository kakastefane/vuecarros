<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'am8iDxucR/h1S06NQtkGyW/x9u5DHell28IITbHCtt06YL9vjzJXQOfsTOraatG6FDtijzK1fr8012fvrKDpww==');
define('SECURE_AUTH_KEY',  'FpAk67bfimYuv/SCou+dP5VQHeBVPSq7yhHHkD9WtngZRmkDCuG0LCYyYmr5evKbicMWNhx8h0/fsq7SmLRuTg==');
define('LOGGED_IN_KEY',    'n92Vnpl5d0N8w0v6HIqRAdMOsMos8Ubn9UstwPGcNlq+H7z6pNiRlCvQ27GGjO6SUFvIF0SooQv4bBES2HUFhw==');
define('NONCE_KEY',        'kjUyMZ8mV3ayZrB6uZ4bSi9OYHAKoJzCY2rL0R4RDre0NIMRjrmluBajXGpomoiLGDqze/PYL02k5U5tJw6sWg==');
define('AUTH_SALT',        'gEMJ6hUnsmFpfyd/LcISegPwM4BMCMPCCijXOdB1gRdcu+mxGhCM0D7mLuABShO+mhQP8i+7vrZeVTWv4qbBAg==');
define('SECURE_AUTH_SALT', '9BGj9bZJotpJLj8OcHeEo+mdSd4zKMbAkcYOujFMkzTez+y5nLO6ZpZL41Vos5cCudxW/q1a9oUG/q5cl5DWdQ==');
define('LOGGED_IN_SALT',   'fGTBhkR+B1Huin4T6CBOWMoFzuMvHu0lCQHcCxLfpmCip2zqSjcAWFtr+Y62tlOiIIGIKsyNMT3ecozQlsk19g==');
define('NONCE_SALT',       '0ssjN8b7pdGkb9GDKMu6nMZYyVESDx1wFfvrJVaDXQ0pi8fVXRWy9KJpJJMef//up1InuVnZ3+D86xDzBpZ5QA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
