/*!40101 SET NAMES binary*/;
/*!40014 SET FOREIGN_KEY_CHECKS=0*/;
/*!40103 SET TIME_ZONE='+00:00' */;
INSERT INTO `wp_users` VALUES
(1,"dev","$P$BGxG7mx91VhNvtINrwtRZ5RIv3emNK.","dev","dev-email@flywheel.local","","2019-08-13 15:05:47","",0,"dev");
